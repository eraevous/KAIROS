import { useState } from "react";
import { Shield, Lock } from "lucide-react";
import ModuleNavigation from "@/components/module-navigation";
import RFPModule from "@/components/rfp-module";
import SOWModule from "@/components/sow-module";
import ProcurementModule from "@/components/procurement-module";
import AnalyticsModule from "@/components/analytics-module";

export default function Dashboard() {
  const [activeModule, setActiveModule] = useState("rfp");

  const renderActiveModule = () => {
    switch (activeModule) {
      case "rfp":
        return <RFPModule />;
      case "sow":
        return <SOWModule />;
      case "procurement":
        return <ProcurementModule />;
      case "analytics":
        return <AnalyticsModule />;
      default:
        return <RFPModule />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <div className="flex-shrink-0">
                <Shield className="text-gov-blue text-2xl w-8 h-8" />
              </div>
              <div>
                <h1 className="text-xl font-semibold text-gray-900">Gov Document Generator</h1>
                <p className="text-sm text-gray-500">Secure AI-Powered Document Creation</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 text-sm text-gray-600">
                <Lock className="w-4 h-4 text-gov-success" />
                <span>Secure Cloud Connected</span>
              </div>
              <div className="flex items-center space-x-2">
                <img 
                  src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&w=40&h=40&fit=crop&crop=face" 
                  alt="User avatar" 
                  className="w-8 h-8 rounded-full"
                />
                <span className="text-sm font-medium text-gray-700">J. Smith</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <ModuleNavigation activeModule={activeModule} onModuleChange={setActiveModule} />
        {renderActiveModule()}
      </div>
    </div>
  );
}
