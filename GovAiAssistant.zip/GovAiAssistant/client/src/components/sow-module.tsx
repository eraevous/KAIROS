import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Clipboard, Settings, Wand2 } from "lucide-react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import DocumentUpload from "./document-upload";
import GeneratedPreview from "./generated-preview";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Progress } from "@/components/ui/progress";
import type { GeneratedDocument, RagConfiguration } from "@shared/schema";

const sowFormSchema = z.object({
  workOrderNumber: z.string().min(1, "Work order number is required"),
  serviceCategory: z.string().min(1, "Service category is required"),
  workDescription: z.string().min(10, "Work description must be at least 10 characters"),
  startDate: z.string().min(1, "Start date is required"),
  endDate: z.string().min(1, "End date is required"),
  budget: z.string().min(1, "Budget is required"),
});

type SOWFormData = z.infer<typeof sowFormSchema>;

export default function SOWModule() {
  const [currentDocument, setCurrentDocument] = useState<GeneratedDocument | null>(null);
  const { toast } = useToast();

  const form = useForm<SOWFormData>({
    resolver: zodResolver(sowFormSchema),
    defaultValues: {
      workOrderNumber: "",
      serviceCategory: "",
      workDescription: "",
      startDate: "",
      endDate: "",
      budget: "",
    },
  });

  const { data: ragConfig } = useQuery<RagConfiguration>({
    queryKey: ["/api/rag-config", "sow"],
    queryFn: async () => {
      const res = await fetch("/api/rag-config/sow", {
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to fetch RAG configuration");
      return res.json();
    },
  });

  const generateMutation = useMutation({
    mutationFn: async (data: SOWFormData) => {
      const res = await apiRequest("POST", "/api/generate-document", {
        title: `SOW - ${data.workOrderNumber}`,
        moduleType: "sow",
        formData: data,
      });
      return res.json();
    },
    onSuccess: (document) => {
      setCurrentDocument(document);
      toast({
        title: "SOW Generated",
        description: "Your Statement of Work has been successfully generated.",
      });
    },
    onError: () => {
      toast({
        title: "Generation Failed",
        description: "Failed to generate SOW. Please try again.",
        variant: "destructive",
      });
    },
  });

  const fineTuneMutation = useMutation({
    mutationFn: async () => {
      // Mock fine-tuning process
      await new Promise(resolve => setTimeout(resolve, 2000));
      return { success: true };
    },
    onSuccess: () => {
      toast({
        title: "Fine-tuning Initiated",
        description: "Model fine-tuning process has been started.",
      });
    },
    onError: () => {
      toast({
        title: "Fine-tuning Failed",
        description: "Failed to initiate fine-tuning. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: SOWFormData) => {
    generateMutation.mutate(data);
  };

  // Mock fine-tuning performance data
  const modelPerformance = 78;
  const trainingDocuments = 47;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      {/* Left Sidebar - Documents & Fine-tuning */}
      <div className="lg:col-span-1">
        <DocumentUpload moduleType="sow" title="SOW Document Library" />
        
        {/* Fine-tuning Interface */}
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">
            <Settings className="inline w-5 h-5 text-gov-blue mr-2" />
            Fine-tuning Controls
          </h3>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Model Performance</label>
              <Progress value={modelPerformance} className="h-2" />
              <p className="text-xs text-gray-500 mt-1">
                Accuracy: {modelPerformance}% (Target: 85%)
              </p>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Training Data</label>
              <p className="text-sm text-gray-600">{trainingDocuments} SOW documents processed</p>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Vector Store Status</label>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-gov-success rounded-full"></div>
                <span className="text-sm text-gray-600">
                  Active ({ragConfig?.embeddingCount || 0} embeddings)
                </span>
              </div>
            </div>
            
            <Button
              onClick={() => fineTuneMutation.mutate()}
              disabled={fineTuneMutation.isPending}
              className="w-full bg-gov-warning hover:bg-orange-700"
            >
              {fineTuneMutation.isPending ? (
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
              ) : (
                <Settings className="w-4 h-4 mr-2" />
              )}
              Initiate Fine-tuning
            </Button>
          </div>
        </div>
      </div>

      {/* Right Content - Generation Interface */}
      <div className="lg:col-span-2">
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-6">
            <Clipboard className="inline w-5 h-5 text-gov-blue mr-2" />
            Statement of Work Generator
          </h3>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="workOrderNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Work Order Number</FormLabel>
                      <FormControl>
                        <Input placeholder="WO-2024-001" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="serviceCategory"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Service Category</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select service category" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="professional-services">Professional Services</SelectItem>
                          <SelectItem value="technical-support">Technical Support</SelectItem>
                          <SelectItem value="consulting-services">Consulting Services</SelectItem>
                          <SelectItem value="maintenance-repair">Maintenance & Repair</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="workDescription"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Work Description</FormLabel>
                    <FormControl>
                      <Textarea
                        rows={4}
                        placeholder="Detailed description of work to be performed..."
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <FormField
                  control={form.control}
                  name="startDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Start Date</FormLabel>
                      <FormControl>
                        <Input type="date" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="endDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>End Date</FormLabel>
                      <FormControl>
                        <Input type="date" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="budget"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Budget</FormLabel>
                      <FormControl>
                        <Input placeholder="$0.00" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="flex justify-end pt-6 border-t border-gray-200">
                <Button
                  type="submit"
                  disabled={generateMutation.isPending}
                  className="bg-gov-blue hover:bg-blue-700"
                >
                  {generateMutation.isPending ? (
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  ) : (
                    <Wand2 className="w-4 h-4 mr-2" />
                  )}
                  Generate SOW
                </Button>
              </div>
            </form>
          </Form>
        </div>

        <GeneratedPreview 
          document={currentDocument} 
          isGenerating={generateMutation.isPending} 
        />
      </div>
    </div>
  );
}
