import { useState, useRef } from "react";
import { Upload, Eye, Trash2 } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { formatFileSize, formatTimeAgo, getFileIcon, getFileIconColor } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import type { Document } from "@shared/schema";

interface DocumentUploadProps {
  moduleType: string;
  title: string;
}

export default function DocumentUpload({ moduleType, title }: DocumentUploadProps) {
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: documents = [], isLoading } = useQuery<Document[]>({
    queryKey: ["/api/documents", moduleType],
    queryFn: async () => {
      const res = await fetch(`/api/documents/${moduleType}`, {
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to fetch documents");
      return res.json();
    },
  });

  const uploadMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append("file", file);
      formData.append("moduleType", moduleType);

      const res = await apiRequest("POST", "/api/documents", formData);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/documents", moduleType] });
      toast({
        title: "Document uploaded",
        description: "Document has been successfully uploaded and processed.",
      });
    },
    onError: () => {
      toast({
        title: "Upload failed",
        description: "Failed to upload document. Please try again.",
        variant: "destructive",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/documents/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/documents", moduleType] });
      toast({
        title: "Document deleted",
        description: "Document has been successfully deleted.",
      });
    },
    onError: () => {
      toast({
        title: "Delete failed",
        description: "Failed to delete document. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleFileSelect = (files: FileList | null) => {
    if (files && files.length > 0) {
      Array.from(files).forEach(file => {
        uploadMutation.mutate(file);
      });
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    handleFileSelect(e.dataTransfer.files);
  };

  return (
    <div className="bg-white rounded-lg shadow p-6 mb-6">
      <h3 className="text-lg font-medium text-gray-900 mb-4">
        <Upload className="inline w-5 h-5 text-gov-blue mr-2" />
        {title}
      </h3>
      
      {/* Upload Zone */}
      <div
        className={`border-2 border-dashed rounded-lg p-6 text-center mb-4 transition-colors cursor-pointer ${
          isDragging
            ? "border-gov-blue bg-blue-50"
            : "border-gray-300 hover:border-gov-blue"
        }`}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
      >
        <Upload className="text-gray-400 text-3xl w-12 h-12 mx-auto mb-3" />
        <p className="text-sm text-gray-600 mb-2">Drag and drop files here, or click to browse</p>
        <input
          ref={fileInputRef}
          type="file"
          className="hidden"
          multiple
          accept=".pdf,.doc,.docx,.txt"
          onChange={(e) => handleFileSelect(e.target.files)}
        />
        <button className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-gov-blue hover:bg-blue-700">
          Choose Files
        </button>
      </div>

      {/* Uploaded Documents */}
      <div className="space-y-3">
        {isLoading ? (
          <div className="flex justify-center py-4">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gov-blue"></div>
          </div>
        ) : documents.length === 0 ? (
          <p className="text-center text-gray-500 py-4">No documents uploaded yet</p>
        ) : (
          documents.map((doc) => (
            <div key={doc.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center space-x-3">
                <i className={`${getFileIcon(doc.mimeType)} ${getFileIconColor(doc.mimeType)}`}></i>
                <div>
                  <p className="text-sm font-medium text-gray-900">{doc.originalName}</p>
                  <p className="text-xs text-gray-500">
                    {formatFileSize(doc.size)} • Uploaded {formatTimeAgo(new Date(doc.uploadedAt!))}
                  </p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <button className="text-gov-blue hover:text-blue-700">
                  <Eye className="w-4 h-4" />
                </button>
                <button
                  onClick={() => deleteMutation.mutate(doc.id)}
                  disabled={deleteMutation.isPending}
                  className="text-red-600 hover:text-red-700 disabled:opacity-50"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
