import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { FileText, Brain, Wand2 } from "lucide-react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import DocumentUpload from "./document-upload";
import GeneratedPreview from "./generated-preview";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Checkbox } from "@/components/ui/checkbox";
import { Slider } from "@/components/ui/slider";
import type { GeneratedDocument, RagConfiguration } from "@shared/schema";

const rfpFormSchema = z.object({
  projectTitle: z.string().min(1, "Project title is required"),
  contractType: z.string().min(1, "Contract type is required"),
  estimatedValue: z.string().min(1, "Estimated value is required"),
  performancePeriod: z.string().min(1, "Performance period is required"),
  projectRequirements: z.string().min(10, "Requirements must be at least 10 characters"),
  template: z.string().default("standard"),
  includeCompliance: z.boolean().default(true),
  includeEvaluation: z.boolean().default(false),
});

type RFPFormData = z.infer<typeof rfpFormSchema>;

export default function RFPModule() {
  const [currentDocument, setCurrentDocument] = useState<GeneratedDocument | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<RFPFormData>({
    resolver: zodResolver(rfpFormSchema),
    defaultValues: {
      projectTitle: "",
      contractType: "",
      estimatedValue: "",
      performancePeriod: "",
      projectRequirements: "",
      template: "standard",
      includeCompliance: true,
      includeEvaluation: false,
    },
  });

  const { data: ragConfig } = useQuery<RagConfiguration>({
    queryKey: ["/api/rag-config", "rfp"],
    queryFn: async () => {
      const res = await fetch("/api/rag-config/rfp", {
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to fetch RAG configuration");
      return res.json();
    },
  });

  const generateMutation = useMutation({
    mutationFn: async (data: RFPFormData) => {
      const res = await apiRequest("POST", "/api/generate-document", {
        title: data.projectTitle,
        moduleType: "rfp",
        formData: data,
      });
      return res.json();
    },
    onSuccess: (document) => {
      setCurrentDocument(document);
      toast({
        title: "RFP Generated",
        description: "Your RFP has been successfully generated.",
      });
    },
    onError: () => {
      toast({
        title: "Generation Failed",
        description: "Failed to generate RFP. Please try again.",
        variant: "destructive",
      });
    },
  });

  const reindexMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/rag-config/rfp/reindex");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/rag-config", "rfp"] });
      toast({
        title: "Reindexing Complete",
        description: "Documents have been successfully reindexed.",
      });
    },
    onError: () => {
      toast({
        title: "Reindexing Failed",
        description: "Failed to reindex documents. Please try again.",
        variant: "destructive",
      });
    },
  });

  const updateSimilarityMutation = useMutation({
    mutationFn: async (threshold: number) => {
      const res = await apiRequest("PATCH", "/api/rag-config/rfp", {
        similarityThreshold: threshold.toString(),
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/rag-config", "rfp"] });
    },
  });

  const onSubmit = (data: RFPFormData) => {
    generateMutation.mutate(data);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      {/* Left Sidebar - Documents & RAG */}
      <div className="lg:col-span-1">
        <DocumentUpload moduleType="rfp" title="RFP Document Library" />
        
        {/* RAG Configuration */}
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">
            <Brain className="inline w-5 h-5 text-gov-blue mr-2" />
            RAG Configuration
          </h3>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Vector Store Status</label>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-gov-success rounded-full"></div>
                <span className="text-sm text-gray-600">
                  Active ({ragConfig?.embeddingCount || 0} embeddings)
                </span>
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Similarity Threshold</label>
              <Slider
                value={[parseFloat(ragConfig?.similarityThreshold || "0.7")]}
                onValueChange={([value]) => updateSimilarityMutation.mutate(value)}
                min={0.1}
                max={1.0}
                step={0.1}
                className="w-full"
              />
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>0.1 (Broad)</span>
                <span>{ragConfig?.similarityThreshold || "0.7"}</span>
                <span>1.0 (Strict)</span>
              </div>
            </div>
            
            <Button
              onClick={() => reindexMutation.mutate()}
              disabled={reindexMutation.isPending}
              className="w-full bg-gov-blue hover:bg-blue-700"
            >
              {reindexMutation.isPending ? (
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
              ) : (
                <Brain className="w-4 h-4 mr-2" />
              )}
              Reindex Documents
            </Button>
          </div>
        </div>
      </div>

      {/* Right Content - Generation Interface */}
      <div className="lg:col-span-2">
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-6">
            <FileText className="inline w-5 h-5 text-gov-blue mr-2" />
            RFP Generation Interface
          </h3>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="projectTitle"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Project Title</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter project title" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="contractType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Contract Type</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select contract type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="fixed-price">Fixed Price</SelectItem>
                          <SelectItem value="time-materials">Time & Materials</SelectItem>
                          <SelectItem value="cost-plus">Cost Plus</SelectItem>
                          <SelectItem value="idiq">IDIQ</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="estimatedValue"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Estimated Value</FormLabel>
                      <FormControl>
                        <Input placeholder="$0 - $100,000" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="performancePeriod"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Performance Period</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g., 12 months" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="projectRequirements"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Project Requirements</FormLabel>
                    <FormControl>
                      <Textarea
                        rows={4}
                        placeholder="Describe the key requirements and objectives..."
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Template Selection */}
              <FormField
                control={form.control}
                name="template"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Base Template</FormLabel>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                      {[
                        { value: "standard", icon: "📄", title: "Standard RFP", desc: "General purpose template" },
                        { value: "it", icon: "💻", title: "IT Services", desc: "Technology focused" },
                        { value: "construction", icon: "🏗️", title: "Construction", desc: "Infrastructure projects" },
                      ].map((template) => (
                        <label
                          key={template.value}
                          className={`flex flex-col items-center p-4 border-2 rounded-lg cursor-pointer hover:border-gov-blue ${
                            field.value === template.value ? "border-gov-blue bg-blue-50" : "border-gray-200"
                          }`}
                        >
                          <input
                            type="radio"
                            value={template.value}
                            checked={field.value === template.value}
                            onChange={field.onChange}
                            className="sr-only"
                          />
                          <span className="text-2xl mb-2">{template.icon}</span>
                          <span className="text-sm font-medium text-gray-900">{template.title}</span>
                          <span className="text-xs text-gray-500">{template.desc}</span>
                        </label>
                      ))}
                    </div>
                  </FormItem>
                )}
              />

              {/* Generation Controls */}
              <div className="flex items-center justify-between pt-6 border-t border-gray-200">
                <div className="flex items-center space-x-4">
                  <FormField
                    control={form.control}
                    name="includeCompliance"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <FormLabel className="text-sm text-gray-600">
                          Include compliance checklist
                        </FormLabel>
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="includeEvaluation"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <FormLabel className="text-sm text-gray-600">
                          Generate evaluation criteria
                        </FormLabel>
                      </FormItem>
                    )}
                  />
                </div>
                
                <Button
                  type="submit"
                  disabled={generateMutation.isPending}
                  className="bg-gov-blue hover:bg-blue-700"
                >
                  {generateMutation.isPending ? (
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  ) : (
                    <Wand2 className="w-4 h-4 mr-2" />
                  )}
                  Generate RFP
                </Button>
              </div>
            </form>
          </Form>
        </div>

        <GeneratedPreview 
          document={currentDocument} 
          isGenerating={generateMutation.isPending} 
        />
      </div>
    </div>
  );
}
