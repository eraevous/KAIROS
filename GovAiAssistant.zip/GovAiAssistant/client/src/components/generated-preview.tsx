import { useState } from "react";
import { Eye, Copy, Download, Check, X, Clock } from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { GeneratedDocument } from "@shared/schema";

interface GeneratedPreviewProps {
  document: GeneratedDocument | null;
  isGenerating: boolean;
}

export default function GeneratedPreview({ document, isGenerating }: GeneratedPreviewProps) {
  const [copied, setCopied] = useState(false);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const statusMutation = useMutation({
    mutationFn: async ({ id, status }: { id: number; status: string }) => {
      await apiRequest("PATCH", `/api/generated-documents/${id}/status`, { status });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/generated-documents"] });
      toast({
        title: "Status updated",
        description: "Document status has been updated successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Update failed",
        description: "Failed to update document status. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleCopy = async () => {
    if (document?.content) {
      try {
        await navigator.clipboard.writeText(document.content);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
        toast({
          title: "Copied to clipboard",
          description: "Document content has been copied to clipboard.",
        });
      } catch (err) {
        toast({
          title: "Copy failed",
          description: "Failed to copy content to clipboard.",
          variant: "destructive",
        });
      }
    }
  };

  const handleExport = () => {
    if (document?.content) {
      const blob = new Blob([document.content], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${document.title}.txt`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      toast({
        title: "Document exported",
        description: "Document has been downloaded successfully.",
      });
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "approved":
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
            <Check className="w-3 h-3 mr-1" />
            Approved
          </span>
        );
      case "rejected":
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
            <X className="w-3 h-3 mr-1" />
            Rejected
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
            <Clock className="w-3 h-3 mr-1" />
            Pending Review
          </span>
        );
    }
  };

  if (isGenerating) {
    return (
      <div className="bg-white rounded-lg shadow p-6 mt-6">
        <div className="flex items-center justify-center py-12">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gov-blue mx-auto mb-4"></div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">Generating Document...</h3>
            <p className="text-gray-600">Processing with secure AI models</p>
          </div>
        </div>
      </div>
    );
  }

  if (!document) {
    return (
      <div className="bg-white rounded-lg shadow p-6 mt-6">
        <div className="text-center py-12">
          <Eye className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No Document Generated</h3>
          <p className="text-gray-600">Fill out the form above and click generate to create a document.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow p-6 mt-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-medium text-gray-900">
          <Eye className="inline w-5 h-5 text-gov-blue mr-2" />
          Generated Preview
        </h3>
        <div className="flex items-center space-x-2">
          <button
            onClick={handleCopy}
            className="text-gov-blue hover:text-blue-700 flex items-center space-x-1"
          >
            {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            <span>{copied ? "Copied" : "Copy"}</span>
          </button>
          <button
            onClick={handleExport}
            className="text-gov-blue hover:text-blue-700 flex items-center space-x-1"
          >
            <Download className="w-4 h-4" />
            <span>Export</span>
          </button>
        </div>
      </div>
      
      <div className="border border-gray-200 rounded-lg p-4 bg-gray-50 max-h-96 overflow-y-auto">
        <div className="prose prose-sm max-w-none">
          <pre className="whitespace-pre-wrap text-sm text-gray-700 font-sans">
            {document.content}
          </pre>
        </div>
      </div>
      
      {/* Approval Controls */}
      <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-200">
        <div className="flex items-center space-x-4">
          <span className="text-sm text-gray-600">Review Status:</span>
          {getStatusBadge(document.status)}
        </div>
        {document.status === "pending" && (
          <div className="flex items-center space-x-3">
            <button
              onClick={() => statusMutation.mutate({ id: document.id, status: "rejected" })}
              disabled={statusMutation.isPending}
              className="bg-red-600 text-white px-4 py-2 rounded-md hover:bg-red-700 transition-colors disabled:opacity-50"
            >
              <X className="w-4 h-4 mr-1" />
              Reject
            </button>
            <button
              onClick={() => statusMutation.mutate({ id: document.id, status: "approved" })}
              disabled={statusMutation.isPending}
              className="bg-gov-success text-white px-4 py-2 rounded-md hover:bg-green-700 transition-colors disabled:opacity-50"
            >
              <Check className="w-4 h-4 mr-1" />
              Approve
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
