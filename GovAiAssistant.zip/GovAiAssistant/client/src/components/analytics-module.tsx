import { useQuery } from "@tanstack/react-query";
import { FileText, Clipboard, FileSignature, Clock, Check, X, History } from "lucide-react";
import { formatTimeAgo } from "@/lib/utils";
import type { AuditTrail } from "@shared/schema";

interface AnalyticsData {
  rfpCount: number;
  sowCount: number;
  memoCount: number;
  avgTime: string;
}

export default function AnalyticsModule() {
  const { data: analytics } = useQuery<AnalyticsData>({
    queryKey: ["/api/analytics"],
    queryFn: async () => {
      const res = await fetch("/api/analytics", {
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to fetch analytics");
      return res.json();
    },
  });

  const { data: auditTrail = [] } = useQuery<AuditTrail[]>({
    queryKey: ["/api/audit-trail"],
    queryFn: async () => {
      const res = await fetch("/api/audit-trail", {
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to fetch audit trail");
      return res.json();
    },
  });

  const metrics = [
    {
      icon: FileText,
      label: "RFPs Generated",
      value: analytics?.rfpCount || 0,
      color: "bg-blue-100 text-gov-blue",
    },
    {
      icon: Clipboard,
      label: "SOWs Created",
      value: analytics?.sowCount || 0,
      color: "bg-green-100 text-gov-success",
    },
    {
      icon: FileSignature,
      label: "Memorandums",
      value: analytics?.memoCount || 0,
      color: "bg-yellow-100 text-gov-warning",
    },
    {
      icon: Clock,
      label: "Avg. Generation Time",
      value: analytics?.avgTime || "0m",
      color: "bg-purple-100 text-purple-600",
    },
  ];

  const getActionIcon = (action: string) => {
    if (action.includes("approved")) return <Check className="w-4 h-4 text-white" />;
    if (action.includes("rejected")) return <X className="w-4 h-4 text-white" />;
    if (action.includes("generated")) return <FileText className="w-4 h-4 text-white" />;
    return <History className="w-4 h-4 text-white" />;
  };

  const getActionColor = (action: string) => {
    if (action.includes("approved")) return "bg-green-500";
    if (action.includes("rejected")) return "bg-red-500";
    if (action.includes("generated")) return "bg-blue-500";
    return "bg-gray-500";
  };

  const getActionDescription = (action: string, details: any) => {
    switch (action) {
      case "document_approved":
        return "Document approved";
      case "document_rejected":
        return "Document rejected";
      case "document_generated":
        return `${details?.moduleType?.toUpperCase() || "Document"} generated`;
      case "document_uploaded":
        return "Document uploaded";
      case "document_deleted":
        return "Document deleted";
      case "rag_reindexed":
        return "Documents reindexed";
      default:
        return action.replace(/_/g, " ");
    }
  };

  return (
    <div>
      {/* Metrics Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-4 gap-6 mb-8">
        {metrics.map((metric, index) => {
          const Icon = metric.icon;
          return (
            <div key={index} className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center">
                <div className={`p-3 rounded-full ${metric.color}`}>
                  <Icon className="w-6 h-6" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-500">{metric.label}</p>
                  <p className="text-2xl font-semibold text-gray-900">{metric.value}</p>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Audit Trail */}
      <div className="bg-white rounded-lg shadow">
        <div className="px-6 py-4 border-b border-gray-200">
          <h3 className="text-lg font-medium text-gray-900">
            <History className="inline w-5 h-5 text-gov-blue mr-2" />
            Recent Activity & Audit Trail
          </h3>
        </div>
        <div className="p-6">
          {auditTrail.length === 0 ? (
            <div className="text-center py-8">
              <History className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500">No activity recorded yet</p>
            </div>
          ) : (
            <div className="flow-root">
              <ul className="-mb-8">
                {auditTrail.map((item, index) => (
                  <li key={item.id}>
                    <div className={`relative ${index !== auditTrail.length - 1 ? "pb-8" : ""}`}>
                      {index !== auditTrail.length - 1 && (
                        <span className="absolute top-4 left-4 -ml-px h-full w-0.5 bg-gray-200"></span>
                      )}
                      <div className="relative flex space-x-3">
                        <div>
                          <span className={`h-8 w-8 rounded-full flex items-center justify-center ring-8 ring-white ${getActionColor(item.action)}`}>
                            {getActionIcon(item.action)}
                          </span>
                        </div>
                        <div className="min-w-0 flex-1 pt-1.5 flex justify-between space-x-4">
                          <div>
                            <p className="text-sm text-gray-500">
                              {getActionDescription(item.action, item.details)} by{" "}
                              <span className="font-medium text-gray-900">User {item.userId}</span>
                            </p>
                            {item.details?.title && (
                              <p className="text-xs text-gray-400">{item.details.title}</p>
                            )}
                            {item.details?.filename && (
                              <p className="text-xs text-gray-400">{item.details.filename}</p>
                            )}
                          </div>
                          <div className="text-right text-sm whitespace-nowrap text-gray-500">
                            <time>{formatTimeAgo(new Date(item.timestamp!))}</time>
                          </div>
                        </div>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
