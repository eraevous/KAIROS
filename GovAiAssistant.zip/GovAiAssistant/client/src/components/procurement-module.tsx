import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { FileSignature, Plus, Wand2 } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import GeneratedPreview from "./generated-preview";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import type { GeneratedDocument } from "@shared/schema";

const procurementFormSchema = z.object({
  subject: z.string().min(1, "Subject is required"),
  description: z.string().min(10, "Description must be at least 10 characters"),
  justification: z.string().min(10, "Justification must be at least 10 characters"),
  marketResearch: z.string().min(10, "Market research must be at least 10 characters"),
  acquisitionStrategy: z.string().min(1, "Acquisition strategy is required"),
  fundingSource: z.string().min(1, "Funding source is required"),
  estimatedCost: z.string().min(1, "Estimated cost is required"),
});

type ProcurementFormData = z.infer<typeof procurementFormSchema>;

export default function ProcurementModule() {
  const [currentDocument, setCurrentDocument] = useState<GeneratedDocument | null>(null);
  const [showForm, setShowForm] = useState(false);
  const { toast } = useToast();

  const form = useForm<ProcurementFormData>({
    resolver: zodResolver(procurementFormSchema),
    defaultValues: {
      subject: "",
      description: "",
      justification: "",
      marketResearch: "",
      acquisitionStrategy: "",
      fundingSource: "",
      estimatedCost: "",
    },
  });

  const generateMutation = useMutation({
    mutationFn: async (data: ProcurementFormData) => {
      const res = await apiRequest("POST", "/api/generate-document", {
        title: `Procurement Memorandum - ${data.subject}`,
        moduleType: "procurement",
        formData: data,
      });
      return res.json();
    },
    onSuccess: (document) => {
      setCurrentDocument(document);
      toast({
        title: "Memorandum Generated",
        description: "Your procurement memorandum has been successfully generated.",
      });
    },
    onError: () => {
      toast({
        title: "Generation Failed",
        description: "Failed to generate memorandum. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: ProcurementFormData) => {
    generateMutation.mutate(data);
  };

  if (!showForm && !currentDocument) {
    return (
      <div className="text-center py-12">
        <FileSignature className="w-16 h-16 text-gray-400 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-900 mb-2">Procurement Memorandum Generator</h3>
        <p className="text-gray-600 mb-6">Generate formal procurement memorandums and justifications</p>
        <Button
          onClick={() => setShowForm(true)}
          className="bg-gov-blue hover:bg-blue-700"
        >
          <Plus className="w-4 h-4 mr-2" />
          Create New Memorandum
        </Button>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      {/* Generation Form */}
      <div className="bg-white rounded-lg shadow p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-medium text-gray-900">
            <FileSignature className="inline w-5 h-5 text-gov-blue mr-2" />
            Procurement Memorandum Form
          </h3>
          {showForm && (
            <Button
              variant="outline"
              onClick={() => {
                setShowForm(false);
                setCurrentDocument(null);
                form.reset();
              }}
            >
              Cancel
            </Button>
          )}
        </div>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="subject"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Subject</FormLabel>
                  <FormControl>
                    <Input placeholder="Procurement request subject" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea
                      rows={3}
                      placeholder="Brief description of what is being procured..."
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="justification"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Business Justification</FormLabel>
                  <FormControl>
                    <Textarea
                      rows={3}
                      placeholder="Explain why this procurement is necessary..."
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="marketResearch"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Market Research Summary</FormLabel>
                  <FormControl>
                    <Textarea
                      rows={3}
                      placeholder="Summary of market research findings..."
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="acquisitionStrategy"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Acquisition Strategy</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., Competitive procurement" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="estimatedCost"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Estimated Cost</FormLabel>
                    <FormControl>
                      <Input placeholder="$0.00" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="fundingSource"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Funding Source</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g., FY2024 Operations Budget" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="flex justify-end pt-6 border-t border-gray-200">
              <Button
                type="submit"
                disabled={generateMutation.isPending}
                className="bg-gov-blue hover:bg-blue-700"
              >
                {generateMutation.isPending ? (
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                ) : (
                  <Wand2 className="w-4 h-4 mr-2" />
                )}
                Generate Memorandum
              </Button>
            </div>
          </form>
        </Form>
      </div>

      {/* Preview */}
      <div>
        <GeneratedPreview 
          document={currentDocument} 
          isGenerating={generateMutation.isPending} 
        />
      </div>
    </div>
  );
}
