import { FileText, Clipboard, FileSignature, BarChart3 } from "lucide-react";

interface ModuleNavigationProps {
  activeModule: string;
  onModuleChange: (module: string) => void;
}

const modules = [
  {
    id: "rfp",
    name: "RFP Generator",
    icon: FileText,
  },
  {
    id: "sow",
    name: "SOW Generator", 
    icon: Clipboard,
  },
  {
    id: "procurement",
    name: "Procurement Memorandum",
    icon: FileSignature,
  },
  {
    id: "analytics",
    name: "Analytics & Audit",
    icon: BarChart3,
  },
];

export default function ModuleNavigation({ activeModule, onModuleChange }: ModuleNavigationProps) {
  return (
    <div className="mb-8">
      <div className="border-b border-gray-200">
        <nav className="-mb-px flex space-x-8">
          {modules.map((module) => {
            const Icon = module.icon;
            const isActive = activeModule === module.id;
            
            return (
              <button
                key={module.id}
                onClick={() => onModuleChange(module.id)}
                className={`${
                  isActive
                    ? "border-gov-blue text-gov-blue"
                    : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                } border-b-2 py-2 px-1 text-sm font-medium flex items-center space-x-2`}
              >
                <Icon className="w-4 h-4" />
                <span>{module.name}</span>
              </button>
            );
          })}
        </nav>
      </div>
    </div>
  );
}
