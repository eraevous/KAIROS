import type { Express } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import { storage } from "./storage";
import { insertDocumentSchema, insertGeneratedDocumentSchema, insertAuditTrailSchema } from "@shared/schema";
import { z } from "zod";

const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Documents endpoints
  app.get("/api/documents/:moduleType", async (req, res) => {
    try {
      const { moduleType } = req.params;
      const documents = await storage.getDocumentsByModule(moduleType);
      res.json(documents);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch documents" });
    }
  });

  app.post("/api/documents", upload.single("file"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No file uploaded" });
      }

      const { moduleType } = req.body;
      if (!moduleType || !["rfp", "sow", "procurement"].includes(moduleType)) {
        return res.status(400).json({ error: "Invalid module type" });
      }

      const document = await storage.createDocument({
        filename: `${Date.now()}-${req.file.originalname}`,
        originalName: req.file.originalname,
        mimeType: req.file.mimetype,
        size: req.file.size,
        moduleType,
        uploadedBy: 1, // Mock user ID
      });

      // Create audit entry
      await storage.createAuditEntry({
        action: "document_uploaded",
        entityType: "document",
        entityId: document.id,
        userId: 1,
        details: { filename: document.originalName, moduleType },
      });

      res.json(document);
    } catch (error) {
      res.status(500).json({ error: "Failed to upload document" });
    }
  });

  app.delete("/api/documents/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteDocument(id);
      
      if (!success) {
        return res.status(404).json({ error: "Document not found" });
      }

      // Create audit entry
      await storage.createAuditEntry({
        action: "document_deleted",
        entityType: "document",
        entityId: id,
        userId: 1,
        details: {},
      });

      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete document" });
    }
  });

  // Generated documents endpoints
  app.get("/api/generated-documents", async (req, res) => {
    try {
      const { moduleType } = req.query;
      const documents = await storage.getGeneratedDocuments(moduleType as string);
      res.json(documents);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch generated documents" });
    }
  });

  app.post("/api/generate-document", async (req, res) => {
    try {
      const validationSchema = insertGeneratedDocumentSchema.extend({
        formData: z.object({}).passthrough(),
      });

      const validated = validationSchema.parse(req.body);

      // Simulate document generation with AI/RAG
      const generatedContent = generateDocumentContent(validated.moduleType, validated.formData);

      const document = await storage.createGeneratedDocument({
        title: validated.title,
        content: generatedContent,
        moduleType: validated.moduleType,
        status: "pending",
        metadata: validated.formData,
        generatedBy: 1, // Mock user ID
      });

      // Create audit entry
      await storage.createAuditEntry({
        action: "document_generated",
        entityType: "generated_document",
        entityId: document.id,
        userId: 1,
        details: { moduleType: validated.moduleType, title: validated.title },
      });

      res.json(document);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid request data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to generate document" });
    }
  });

  app.patch("/api/generated-documents/:id/status", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { status } = req.body;

      if (!["approved", "rejected"].includes(status)) {
        return res.status(400).json({ error: "Invalid status" });
      }

      const success = await storage.updateGeneratedDocumentStatus(id, status, 1);
      
      if (!success) {
        return res.status(404).json({ error: "Document not found" });
      }

      // Create audit entry
      await storage.createAuditEntry({
        action: `document_${status}`,
        entityType: "generated_document",
        entityId: id,
        userId: 1,
        details: { status },
      });

      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to update document status" });
    }
  });

  // RAG configuration endpoints
  app.get("/api/rag-config/:moduleType", async (req, res) => {
    try {
      const { moduleType } = req.params;
      const config = await storage.getRagConfiguration(moduleType);
      
      if (!config) {
        return res.status(404).json({ error: "RAG configuration not found" });
      }

      res.json(config);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch RAG configuration" });
    }
  });

  app.patch("/api/rag-config/:moduleType", async (req, res) => {
    try {
      const { moduleType } = req.params;
      const { similarityThreshold } = req.body;

      const config = await storage.updateRagConfiguration(moduleType, {
        similarityThreshold,
        lastReindexed: new Date(),
      });

      res.json(config);
    } catch (error) {
      res.status(500).json({ error: "Failed to update RAG configuration" });
    }
  });

  app.post("/api/rag-config/:moduleType/reindex", async (req, res) => {
    try {
      const { moduleType } = req.params;
      
      // Simulate reindexing process
      const newEmbeddingCount = Math.floor(Math.random() * 1000) + 2000;
      
      const config = await storage.updateRagConfiguration(moduleType, {
        embeddingCount: newEmbeddingCount,
        lastReindexed: new Date(),
      });

      // Create audit entry
      await storage.createAuditEntry({
        action: "rag_reindexed",
        entityType: "rag_configuration",
        entityId: config.id,
        userId: 1,
        details: { moduleType, embeddingCount: newEmbeddingCount },
      });

      res.json(config);
    } catch (error) {
      res.status(500).json({ error: "Failed to reindex documents" });
    }
  });

  // Audit trail endpoint
  app.get("/api/audit-trail", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 50;
      const auditEntries = await storage.getAuditTrail(limit);
      res.json(auditEntries);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch audit trail" });
    }
  });

  // Analytics endpoint
  app.get("/api/analytics", async (req, res) => {
    try {
      const allDocs = await storage.getGeneratedDocuments();
      
      const metrics = {
        rfpCount: allDocs.filter(doc => doc.moduleType === "rfp").length,
        sowCount: allDocs.filter(doc => doc.moduleType === "sow").length,
        memoCount: allDocs.filter(doc => doc.moduleType === "procurement").length,
        avgTime: "3.2m", // Mock average generation time
      };

      res.json(metrics);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch analytics" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

function generateDocumentContent(moduleType: string, formData: any): string {
  const templates = {
    rfp: `REQUEST FOR PROPOSAL (RFP)

Project: ${formData.projectTitle || "Untitled Project"}

1. PROJECT OVERVIEW
The Department seeks qualified contractors to provide ${formData.projectRequirements || "comprehensive services"}.

Contract Type: ${formData.contractType || "Not specified"}
Estimated Value: ${formData.estimatedValue || "TBD"}
Performance Period: ${formData.performancePeriod || "TBD"}

2. SCOPE OF WORK
${formData.projectRequirements || "Detailed requirements to be defined based on project needs."}

3. SUBMISSION REQUIREMENTS
Proposals must include technical approach, project timeline, cost breakdown, and contractor qualifications.

4. EVALUATION CRITERIA
- Technical capability (40%)
- Past performance (30%)
- Cost (20%)
- Management approach (10%)

5. SUBMISSION DEADLINE
Proposals must be submitted by [DATE] to [SUBMISSION LOCATION].`,

    sow: `STATEMENT OF WORK (SOW)

Work Order: ${formData.workOrderNumber || "WO-XXXX-XXX"}

1. WORK DESCRIPTION
${formData.workDescription || "Detailed description of work to be performed."}

2. SERVICE CATEGORY
${formData.serviceCategory || "Professional Services"}

3. PERFORMANCE PERIOD
Start Date: ${formData.startDate || "TBD"}
End Date: ${formData.endDate || "TBD"}

4. BUDGET
Total Budget: ${formData.budget || "$0.00"}

5. DELIVERABLES
- Detailed project plan
- Regular progress reports
- Final deliverable documentation
- Knowledge transfer sessions

6. ACCEPTANCE CRITERIA
All deliverables must meet the specified requirements and be approved by the designated government representative.`,

    procurement: `PROCUREMENT MEMORANDUM

To: Contracting Officer
From: Requesting Official
Date: ${new Date().toLocaleDateString()}
Subject: Procurement Request - ${formData.subject || "Service Request"}

1. PURPOSE
This memorandum requests approval for the procurement of ${formData.description || "required services"}.

2. JUSTIFICATION
${formData.justification || "Business justification for the procurement requirement."}

3. MARKET RESEARCH
Market research indicates that ${formData.marketResearch || "competitive solutions are available"}.

4. ACQUISITION STRATEGY
Recommended acquisition approach: ${formData.acquisitionStrategy || "Competitive procurement"}

5. FUNDING
Funding source: ${formData.fundingSource || "TBD"}
Estimated cost: ${formData.estimatedCost || "TBD"}

6. RECOMMENDATION
It is recommended that this procurement be approved and executed in accordance with applicable regulations.`
  };

  return templates[moduleType as keyof typeof templates] || "Document content could not be generated.";
}
