import { 
  users, documents, generatedDocuments, auditTrail, ragConfigurations,
  type User, type InsertUser,
  type Document, type InsertDocument,
  type GeneratedDocument, type InsertGeneratedDocument,
  type AuditTrail, type InsertAuditTrail,
  type RagConfiguration, type InsertRagConfiguration
} from "@shared/schema";

export interface IStorage {
  // User management
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Document management
  getDocumentsByModule(moduleType: string): Promise<Document[]>;
  createDocument(document: InsertDocument): Promise<Document>;
  deleteDocument(id: number): Promise<boolean>;

  // Generated documents
  getGeneratedDocuments(moduleType?: string): Promise<GeneratedDocument[]>;
  getGeneratedDocument(id: number): Promise<GeneratedDocument | undefined>;
  createGeneratedDocument(document: InsertGeneratedDocument): Promise<GeneratedDocument>;
  updateGeneratedDocumentStatus(id: number, status: string, reviewedBy: number): Promise<boolean>;

  // Audit trail
  getAuditTrail(limit?: number): Promise<AuditTrail[]>;
  createAuditEntry(entry: InsertAuditTrail): Promise<AuditTrail>;

  // RAG configurations
  getRagConfiguration(moduleType: string): Promise<RagConfiguration | undefined>;
  updateRagConfiguration(moduleType: string, config: Partial<InsertRagConfiguration>): Promise<RagConfiguration>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private documents: Map<number, Document>;
  private generatedDocuments: Map<number, GeneratedDocument>;
  private auditTrail: Map<number, AuditTrail>;
  private ragConfigurations: Map<string, RagConfiguration>;
  private currentUserId: number;
  private currentDocumentId: number;
  private currentGeneratedDocumentId: number;
  private currentAuditId: number;
  private currentRagConfigId: number;

  constructor() {
    this.users = new Map();
    this.documents = new Map();
    this.generatedDocuments = new Map();
    this.auditTrail = new Map();
    this.ragConfigurations = new Map();
    this.currentUserId = 1;
    this.currentDocumentId = 1;
    this.currentGeneratedDocumentId = 1;
    this.currentAuditId = 1;
    this.currentRagConfigId = 1;

    // Initialize default user
    this.createUser({
      username: "admin",
      password: "admin",
      role: "admin"
    });

    // Initialize RAG configurations
    ["rfp", "sow", "procurement"].forEach(moduleType => {
      const config: RagConfiguration = {
        id: this.currentRagConfigId++,
        moduleType,
        similarityThreshold: "0.7",
        embeddingCount: Math.floor(Math.random() * 3000) + 1000,
        lastReindexed: new Date(),
      };
      this.ragConfigurations.set(moduleType, config);
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getDocumentsByModule(moduleType: string): Promise<Document[]> {
    return Array.from(this.documents.values()).filter(doc => doc.moduleType === moduleType);
  }

  async createDocument(insertDocument: InsertDocument): Promise<Document> {
    const id = this.currentDocumentId++;
    const document: Document = {
      ...insertDocument,
      id,
      uploadedAt: new Date(),
    };
    this.documents.set(id, document);
    return document;
  }

  async deleteDocument(id: number): Promise<boolean> {
    return this.documents.delete(id);
  }

  async getGeneratedDocuments(moduleType?: string): Promise<GeneratedDocument[]> {
    const docs = Array.from(this.generatedDocuments.values());
    return moduleType ? docs.filter(doc => doc.moduleType === moduleType) : docs;
  }

  async getGeneratedDocument(id: number): Promise<GeneratedDocument | undefined> {
    return this.generatedDocuments.get(id);
  }

  async createGeneratedDocument(insertDoc: InsertGeneratedDocument): Promise<GeneratedDocument> {
    const id = this.currentGeneratedDocumentId++;
    const document: GeneratedDocument = {
      ...insertDoc,
      id,
      generatedAt: new Date(),
      reviewedAt: null,
    };
    this.generatedDocuments.set(id, document);
    return document;
  }

  async updateGeneratedDocumentStatus(id: number, status: string, reviewedBy: number): Promise<boolean> {
    const doc = this.generatedDocuments.get(id);
    if (!doc) return false;

    const updatedDoc: GeneratedDocument = {
      ...doc,
      status,
      reviewedBy,
      reviewedAt: new Date(),
    };
    this.generatedDocuments.set(id, updatedDoc);
    return true;
  }

  async getAuditTrail(limit = 50): Promise<AuditTrail[]> {
    return Array.from(this.auditTrail.values())
      .sort((a, b) => b.timestamp!.getTime() - a.timestamp!.getTime())
      .slice(0, limit);
  }

  async createAuditEntry(insertEntry: InsertAuditTrail): Promise<AuditTrail> {
    const id = this.currentAuditId++;
    const entry: AuditTrail = {
      ...insertEntry,
      id,
      timestamp: new Date(),
    };
    this.auditTrail.set(id, entry);
    return entry;
  }

  async getRagConfiguration(moduleType: string): Promise<RagConfiguration | undefined> {
    return this.ragConfigurations.get(moduleType);
  }

  async updateRagConfiguration(moduleType: string, config: Partial<InsertRagConfiguration>): Promise<RagConfiguration> {
    const existing = this.ragConfigurations.get(moduleType);
    const updated: RagConfiguration = {
      id: existing?.id || this.currentRagConfigId++,
      moduleType,
      similarityThreshold: config.similarityThreshold || existing?.similarityThreshold || "0.7",
      embeddingCount: config.embeddingCount || existing?.embeddingCount || 0,
      lastReindexed: config.lastReindexed || new Date(),
    };
    this.ragConfigurations.set(moduleType, updated);
    return updated;
  }
}

export const storage = new MemStorage();
